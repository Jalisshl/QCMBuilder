import java.util.ArrayList;

public class Admins /** BD Liste des admins*/ {
    private ArrayList<Admin> admins;
    public Admins(){
        admins = new ArrayList<>();
    }
}
