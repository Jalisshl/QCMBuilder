public enum Difficulté /** enum de la difficulté*/{
    Facile, Standard, Difficile,Piège
}
