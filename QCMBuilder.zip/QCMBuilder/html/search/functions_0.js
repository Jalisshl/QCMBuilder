var searchData=
[
  ['admin_0',['Admin',['../class_admin.html#a729aaca65e62de6aa5cf431489d8a53d',1,'Admin']]]
];
