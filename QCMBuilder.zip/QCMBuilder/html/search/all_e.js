var searchData=
[
  ['user_0',['User',['../class_user.html',1,'']]],
  ['users_1',['Users',['../class_users.html',1,'']]]
];
