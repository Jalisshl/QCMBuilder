var searchData=
[
  ['loginterface_0',['LogInterface',['../class_log_interface.html',1,'']]]
];
