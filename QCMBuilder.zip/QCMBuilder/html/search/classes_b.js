var searchData=
[
  ['role_0',['Role',['../enum_role.html',1,'']]]
];
